from click_up.classes.client import ClickUp # noqa
